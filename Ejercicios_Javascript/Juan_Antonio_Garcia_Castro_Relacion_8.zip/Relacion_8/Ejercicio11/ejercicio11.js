function mostrarParrafo(parrafo) {
    const parrafoCompleto = parrafo.querySelector('.parrafo-completo');
    parrafoCompleto.classList.remove('parrafo-completo');
    parrafoCompleto.classList.add('mostrar');
}