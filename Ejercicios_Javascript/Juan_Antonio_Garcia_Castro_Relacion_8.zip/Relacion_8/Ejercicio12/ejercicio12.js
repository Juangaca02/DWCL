function cambiarFondo() {
    document.body.classList.toggle('conImagen');
}
