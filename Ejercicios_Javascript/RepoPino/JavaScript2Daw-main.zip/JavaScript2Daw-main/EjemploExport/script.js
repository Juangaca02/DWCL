import aa, { suma } from './miModulo.js'

console.log(suma(5, 3)); // Resultado: 8
console.log(aa(10, 2)); // Resultado: 8