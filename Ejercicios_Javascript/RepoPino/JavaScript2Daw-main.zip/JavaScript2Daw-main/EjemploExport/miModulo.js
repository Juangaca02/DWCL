export const suma = (a, b) => a + b;
const resta = (a, b) => a - b;

export default resta