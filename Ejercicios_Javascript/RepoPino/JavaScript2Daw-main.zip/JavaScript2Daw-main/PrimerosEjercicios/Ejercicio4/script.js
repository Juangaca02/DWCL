

const aparecer = num => {
    document.write(num + "<br>")
}

for (let index = 1; index <= 15; index++) {
    aparecer(index)
    
}
