let ventana

const abrir = () =>{
    ventana = window.open("https://educacionadistancia.juntadeandalucia.es/centros/cordoba/pluginfile.php/257458/mod_resource/content/2/RELACI%C3%93N%20DE%20EJERCICIOS%20B%C3%81SICOS%20JAVASCRIPT.pdf")
}

const cerrar = () =>{
    ventana.close()
}