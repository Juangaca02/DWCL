const titulo = num => {
    document.write(`<h${num}>TITULO ${num}</h${num}><br>`)
}

for (let index = 1; index <= 6; index++) {
    titulo(index)
    
}